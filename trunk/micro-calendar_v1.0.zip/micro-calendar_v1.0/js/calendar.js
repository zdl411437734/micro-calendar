var seletedtd_cache="20120701";  
var seleted_tip="mail_tip";
var event_edit_input_time="00:00";

/*点击事件*/
$(document).ready(  

	function(){
		
$(document).click(function () { 
			popclose();
			tipclose();
});

$("#header").click(
		
	function(event){ 
			  event.stopPropagation();
});

$("#ckepop").click(
		
	function(event){ 
			  event.stopPropagation();
});

/*$("#footer").click(
		
	function(event){ 
			  event.stopPropagation();
});*/
		
$("#search>input").keyup(
						 
	function(){ 
			  searchdate($(this).val()); 
});

$("#search>input").bind({
        focus: function() {
            if($(this).val() == "搜索日期/日程/备忘")  
           	   $(this).val("");   
        },
        blur: function() {
            if($(this).val() == "")  
           	   $(this).val("搜索日期/日程/备忘"); 
        }
});
		
$("#search>a").click(
		
	function(){ 
			  searchdata($("#search>input").val());
});
		
$("#menu>ul>li:eq(0)").click(
	
	function(){ 
              window.location.href="mycalendar.php";
});

$("#menu>ul>li:eq(0)").hover(
     
	 function () {
		 	  $(this).addClass("home_hover");
  	 },
  	 function () {
		 	  $(this).removeClass("home_hover");
  	 }	
);
		
$("#menu>ul>li:eq(1)").click(
	
	function(){ 
              AddFavorite("wrili.sinaapp.com","微日历——订阅管理日程安排、备忘任务的好帮手");
});

$("#menu>ul>li:eq(1)").hover(
     
	 function () {
		 	  $(this).addClass("home_hover");
  	 },
  	 function () {
		 	  $(this).removeClass("home_hover");
  	 }	
);
		
$("#menu>ul>li:eq(2)").hover(
     
	 function () {
			  $(".user_ul").show();
			  $(".user_ul li:eq(0)").click(
					function(){ 
							 get_mail_tip("#mail_tip"); 
			  });
			  $(".user_ul li:eq(1)").click(
					function(){ 
							 gethelp(); 
			  });
			  $(".user_ul li:eq(2)").click(
					function(){ 
							 window.location.href="quit.php"; 
			  });
			  
			  $(".user_ul li").hover(
     
					function () {
						$(this).css("background-color","#DBDBDB");
					},
					 function () {
						$(this).css("background-color","#FFFFF0");
					}	
					
					
			  );
  	 },
  	 function () {
    		  $(".user_ul").hide();
  	 }	
);
		
$("#mail_tip").click(
     
	 function (event) {
		   	get_mail_tip(this);
			event.stopPropagation();
});
		
$("#todaytask_tip").click(
       
	   function (event) {
		   	get_todaytask_tip(this);
			event.stopPropagation();
});
		
$("#smallcalendar_tip").click(
       
	  function (event) {
		   	get_smallcalendar_tip(this);
			event.stopPropagation();
});
		
$("#calendar_list>a:eq(0)").click(
	  
	  function(event){
            get_bigcalendar();
			$("#calendar_list").css("background","url(/imgs/qiehuanshitu.gif) top left");
			event.stopPropagation();
});
		
$("#calendar_list>a:eq(1)").click(
	  
	  function(event){
			getmonList(0);
			event.stopPropagation();
});

	
get_bigcalendar();   //初始化当月日历
getDate_info();      //获取日期信息
	
}); 
	

/*主要函数*/

/*三个工具图标*/

//获取邮箱信息
function get_mail_tip(obj){
	popclose();
	tipclose();
	if($(obj).find("ul").is(":hidden")){
			$.ajax({
				type: "post",
				data: "action=get_emails",
				url:  "ajax/emails_function.php",
				beforeSend: function(XMLHttpRequest){
					$(obj).find("ul").html("");
				   	$(obj).find("ul").html("<li><img src='imgs/loading.gif' /></li>");
				},
				success: function(data, textStatus){
					$(obj).find("ul").html("");
				   	$(obj).find("ul").html(data);
				},
				error: function(){
					$(obj).find("ul").html("");
				  	$(obj).find("ul").html("<li>加载失败！</li>");
				}
			});
	}
    $(obj).find("ul").toggle();
	$(obj).find("span").toggle();
	seleted_tip="mail_tip";
	$(obj).find("ul").click(
           		function(event){
					event.stopPropagation();
	});
}

function get_todaytask_tip(obj){
	popclose();
	tipclose();
	if($(obj).find("ul").is(":hidden")){
			$.ajax({
				type: "post",
				data: "action=get_today_tasks",
				url:  "ajax/tasks_function.php",
				beforeSend: function(XMLHttpRequest){
					$(obj).find("ul").html("");
				    $(obj).find("ul").html("<li><img src='imgs/loading.gif' /></li>");
				},
				success: function(data, textStatus){
					$(obj).find("ul").html("");
				    $(obj).find("ul").html(data);
					if($(obj).find("ul").height()>=575){
						var b = $(obj).find("ul").height()-575;
						$(".clear").css("margin-top",b+560+"px");
					}
				},
				error: function(){
					$(obj).find("ul").html("");
				    $(obj).find("ul").html("<li>加载失败！</li>");
				}
			});
	}
    $(obj).find("ul").toggle();
	$(obj).find("span").toggle();
	seleted_tip="todaytask_tip";
	$(obj).find("ul").click(
           		function(event){
					event.stopPropagation();
	});
}

function get_smallcalendar_tip(obj){
	popclose();
	tipclose();
	if($(obj).find("ul").is(":hidden")){
			$.ajax({
				type: "post",
				dataType: "json",
				url: "ajax/time_function.php",
				beforeSend: function(XMLHttpRequest){
					$(obj).find("ul").html("");
				    $(obj).find("ul").html("<li><img src='imgs/loading.gif' /></li>");
				},
				success: function(data, textStatus){
					$.ajax({
						type: "post",
						data: "action=get_smallcalendar&year="+data.year+"&mon="+data.mon,
						url: "ajax/calendars_function.php",
						success: function(data, textStatus){
							$(obj).find("ul").html("");
						    $(obj).find("ul").html(data);
						},
						error: function(){
							$(obj).find("ul").html("");
						    $(obj).find("ul").html("<li>加载失败！</li>");
						}
				   });	
				},
				error: function(){
					$(obj).find("ul").html("");
				    $(obj).find("ul").html("<li>加载失败！</li>");
				}
			});
	}
    $(obj).find("ul").toggle();
	$(obj).find("span").toggle();
	seleted_tip="smallcalendar_tip";
	$(obj).find("ul").click(
           	function(event){
				event.stopPropagation();
	});
}


/*搜索*/

//输入框中立即搜索日期
function searchdate(date){
	
	if(isNaN(date)==false&&date.length>=6&&date.length<=8){
	var search_year=date.substr(0,4);
	if(date.substr(4,1)=="0")
		var search_mon=date.substr(5,1);
	else 
        var search_mon=date.substr(4,2);	 
	if(search_year>=1980&&search_year<=2030&&search_mon>=1&&search_mon<=12){
		bigcalendar_change(search_year,search_mon);
	}
	else 
		$("#calendar").html("<div class='red_tips'>&nbsp;对不起，您要找的日期不存在！</div>"); 
	}
}

//输入框搜索具体内容
function searchdata(keyword){
	if(keyword.replace(/\s+/g, "")!=""){
		$.ajax({
				type: "post",
				data: "action=search_data&keyword="+trim(keyword),
				url:  "ajax/other_function.php",
				beforeSend: function(XMLHttpRequest){
						show_loading();
				},
				success: function(data, textStatus){
						$("#calendar").html("");
						$("#calendar").html(data);
						hide_loading();
				},
				error: function(){
						$("#calendar").html("");
						$("#calendar").html("<li>加载失败！</li>");
						hide_loading();
				}
		});
	 }
	else 
		alert("您搜索的内容不能为空！");
}
	

/*显示任务列表样式*/	

//显示任务列表
function getmonList(a){
	 if(isNaN(a)==false&&parseInt(a)>=0){
	  	$.ajax({
				type: "post",
				data: "action=get_task_list&first="+a,
				url: "ajax/tasks_function.php",
				beforeSend: function(XMLHttpRequest){
						show_loading();
				},
				success: function(data, textStatus){
						$("#calendar").html("");
						$("#calendar").html(data);
						hide_loading();
						$("#calendar_list").css("background","url(../imgs/qiehuanshitu.gif) bottom left");
				},
				error: function(){
						$("#calendar").html("");
						$("#calendar").html("<li>加载失败！</li>");
						hide_loading();
				}
		 });
	 }
}

//删除列表样式下的一条信息
function deleteoneTask_List(obj,id){    
	
	   $.ajax({
			  type: "post",
			  data: "action=delete_one_task&id="+id,
			  url: "ajax/tasks_function.php",
			  beforeSend: function(XMLHttpRequest){
					show_loading();
			  },
			  success: function(data, textStatus){
					$(obj).parents("span").hide();
					hide_loading();
			  },
			  error: function(){
					alert("删除失败！");
					hide_loading();
			}
		});
}

/*日历样式*/

//获取日历样式
function get_bigcalendar(){
		$.ajax({
				type: "post",
				dataType: "json",
				url: "ajax/time_function.php",
				beforeSend: function(XMLHttpRequest){
				    show_loading();
				},
				success: function(data, textStatus){
					$.ajax({
						type: "post",
						data: "action=get_bigcalendar&year="+data.year+"&mon="+data.mon,
						url:  "ajax/calendars_function.php",
						success: function(data, textStatus){
							$("#calendar").html("");
							$("#calendar").html(data);
							/*$("#big_calendar").click(           					
								function(event){
									event.stopPropagation();
							});*/
							$("#big_calendar .position_div").click(
								function(event){
									poptask(this);
									event.stopPropagation();
							});
							calendar_change_button();
							hide_loading();	
						},
						error: function(){
							$("#calendar").html("");
						  	alert("加载失败！");
							hide_loading();
						}
					}); 
				},
				error: function(){
					 $("#calendar").html("");
				     alert("加载失败！");
				}
	     });
}

//小型日历上一月下一月操作
function smallcalendar_change(year,mon){
		
		$.ajax({
				type: "post",
				data: "action=get_smallcalendar&year="+year+"&mon="+mon,
				url: "ajax/calendars_function.php",
				beforeSend: function(XMLHttpRequest){
					$("#smallcalendar_tip>ul").html("");
					$("#smallcalendar_tip>ul").html("<li><img src='imgs/loading.gif' /></li>");
				},
				success: function(data, textStatus){
					$("#smallcalendar_tip>ul").html("");
					$("#smallcalendar_tip>ul").html(data);
				},
				error: function(){
					$("#smallcalendar_tip>ul").html("");
					$("#smallcalendar_tip>ul").html("<li>加载失败！</li>");
				}
		});
}

//大日历上一月下一月操作
function bigcalendar_change(year,mon){
		
		$.ajax({
				type: "post",
				data: "action=get_bigcalendar&year="+year+"&mon="+mon,
				url: "ajax/calendars_function.php",
				beforeSend: function(XMLHttpRequest){
						show_loading();
						set_clear_margin_top();
				},
				success: function(data, textStatus){
						$("#calendar").html("");
						$("#calendar").html(data);
						/*$("#big_calendar").click(           					
								function(event){
									event.stopPropagation();
						});*/
						$("#big_calendar .position_div").click(
								function(event){
									poptask(this);
									event.stopPropagation();
						});
						calendar_change_button();
						hide_loading();	
				},
				error: function(){
						$("#calendar").html("");
						alert("加载失败！");
						hide_loading();	
				}
		});
}

//左翻和右翻按钮移动事件
function calendar_change_button(){
		
		$(".bigcalendar_left").hover(
			 
			 function () {
					  $(this).addClass("bigcalendar_left1");
			 },
			 function () {
					  $(this).removeClass("bigcalendar_left1");
			 }	
		);

		$(".bigcalendar_right").hover(
			 
			 function () {
					  $(this).addClass("bigcalendar_right1");
			 },
			 function () {
					  $(this).removeClass("bigcalendar_right1");
			 }	
		);
		
		$(".bigcalendar_left").click(
           		function(event){
					event.stopPropagation();
		});
		
		$(".bigcalendar_right").click(
           		function(event){
					event.stopPropagation();
		});
}
		
/*task弹窗*/

//task窗口弹出
function poptask(obj){
		popclose();
		tipclose();
		if(obj.id!=""){
			$("#"+seletedtd_cache).css("z-index",1);
			$(obj).css("z-index",5);
            seletedtd_cache=obj.id;
   			$(obj).find(".maketask").html("<ul><li class='add_title'><a>Task&nbsp;</a><d>|</d><a style='color:#133DB6' href='javascript:void(0);'>&nbsp;Event&nbsp;</a><a class='add_loading'></a><a title='关闭' class='add_close'><img src='imgs/close.gif'/></a></li><li class='add_time'>"+get_pop_dayinfo(obj.id)+"</li><li class='add_task'>事情：<input id='task' type='text'/></li><li class='add'><input type='checkbox' id='bw'/>标记为备忘&nbsp;<input type='checkbox' id='share_wb'/>分享到新浪微博<a class='add_button'>添加</a></li><li class='task_triganle'></li></ul>");
			$(obj).find(".maketask").find("a:eq(1)").click(
           		function(event){
					popevent(this);
			});
			$(obj).find(".maketask").find(".add_close").click(
           		function(event){
					popclose();
			});
			$(obj).find(".maketask").find(".add_button").click(
           		function(event){
					add_a_task(this);
			});
			$(obj).find(".maketask").click(
           		function(event){
					event.stopPropagation();
			});
			$(obj).find(".maketask").show();	
		}		
}

//新增任务
function add_a_task(obj){
		   		   
		var task_input=$(obj).parents("ul").find("#task").val();
		var ctime = seletedtd_cache.substr(0,4)+"-"+seletedtd_cache.substr(4,2)+"-"+seletedtd_cache.substr(6,2);
		var	ntime =    $(obj).parents("ul").find(".add_time").find("span:eq("+4+")").html()
				     + $(obj).parents("ul").find(".add_time").find("span:eq("+3+")").html()
					 + $(obj).parents("ul").find(".add_time").find("span:eq("+2+")").html()
					 + $(obj).parents("ul").find(".add_time").find("span:eq("+1+")").html()
					 + $(obj).parents("ul").find(".add_time").find("span:eq("+0+")").html();
			
		var bw="false";		   
		if($(obj).parents("ul").find("#bw").attr("checked")=="checked")
			bw="true";
		var share_wb="false";
		if($(obj).parents("ul").find("#share_wb").attr("checked")=="checked")
			share_wb="true";
		if(task_input.replace(/\s+/g, "")=="")
			alert("您的任务不能为空！");
		else if(task_input.indexOf("<")!=-1||task_input.indexOf(">")!=-1) {
			alert("您输入的内容带有特殊符号，请重新输入！");
		}
       	else{
			$.ajax({
					type: "post",
					data: "action=add_one_task&ctime="+ctime+"&task="+task_input+"&ntime="+ntime+"&bw="+bw+"&share_wb="+share_wb,
					url:  "ajax/tasks_function.php",
					beforeSend: function(XMLHttpRequest){
						showloading(".maketask");
					},
					success: function(data, textStatus){	
						$("#"+seletedtd_cache+">div:eq(2)").addClass("div_dis").removeClass("dis_none");
				 		$("#"+seletedtd_cache+">div:eq(2)").html("<a href='mycalendar.php' onclick='canclevent(event)'>有新日程！</a>");
						setTimeout(function(){hideloading(".maketask");},500);
					},
					error: function(){
						alert("新建任务失败！");
					}
			});
   		 }
}

//返回当前点击框的日期和时间信息
function get_pop_dayinfo(a){

		var y=parseInt(a.substr(0,4));   //年份
		if(a.charAt(4)=="0")             //月份
			var m=a.substr(5,1);
		else 
			var m=a.substr(4,2);		  
		if(a.charAt(6)=="0")		     //日
			var d=a.substr(7,1);
		else 
			var d=a.substr(6,2);
				
		var sDate=new Date();            //星期数
		sDate.setFullYear(y,m-1,d);
		var week=new Array("日","一","二","三","四","五","六");
			
		var nDate=new Date();
   		var hour=nDate.getHours();       //小时
		var mins=nDate.getMinutes();     //分钟
		var hour1=(hour-hour%10)/10;
		var hour2=hour%10;
		var mins1=(mins-mins%10)/10;
		var mins2=mins%10;
			
		return "时间：星期"+week[sDate.getDay()]+"  "+y+"年"+m+"月"+d+"日 "+"<span onclick='solidMinG(this)'>"+mins2+"</span><span onclick='solidMinS(this)'>"+mins1+"</span><span>:</span><span onclick='solidHourG(this)'>"+hour2+"</span><span onclick='solidHourS(this)'>"+hour1+"</span>";
}   

/*写任务时点击调整任务具体的时间（小时和分钟）*/	
function solidHourS(obj){  //增加小时的十位
    	var HourS=$(obj).html();
		var HourG=$("#"+seletedtd_cache+">.maketask>ul>.add_time>span:eq("+3+")").html();
	
		if(HourS>=1&&HourG>3) {
			$(obj).html("0");} 
		else if(HourS>=2){
			$(obj).html("0");} 
		else{
	   	 $(obj).html(++HourS);	
		}
}

function solidHourG(obj){  //增加小时的个位数
    	var HourG=$(obj).html();
		var HourS=$("#"+seletedtd_cache+">.maketask>ul>.add_time>span:eq("+4+")").html();
		if (HourS>=2&&HourG>=3){
			$(obj).html("0");} 
		else if(HourG>=9){
			$(obj).html("0");
		}
		else{
			$(obj).html(++HourG);
		}
}

function solidMinS(obj){  //增加分钟的十位
    	var MinS=$(obj).html();
		if(MinS>=5) {
			$(obj).html("0");
		}
		else{
			$(obj).html(++MinS);
		}
}

function solidMinG(obj){  //增加分钟的个位
    	var MinG=$(obj).html();
		if(MinG>=9) {
			$(obj).html("0");
		}
		else{
			$(obj).html(++MinG);
		}
}

function showtask(){
		$("#"+seletedtd_cache+">.maketask").show();	
		$("#"+seletedtd_cache+">.event").hide();
		set_clear_margin_top();
}

function showevent(){
		$("#"+seletedtd_cache+">.maketask").hide();
		$("#"+seletedtd_cache+">.event").show();
}
		

/*event窗口*/

//event窗口弹出
function popevent(obj){

		var ctime = seletedtd_cache.substr(0,4)+"-"+seletedtd_cache.substr(4,2)+"-"+seletedtd_cache.substr(6,2);
		$.ajax({
				type: "post",
				data: "action=get_task_pop&ctime="+ctime,
				url: "ajax/tasks_function.php",
				beforeSend: function(XMLHttpRequest){
					$(obj).parents("td").find(".event").html("");
					$(obj).parents("td").find(".event").html("<ul><li class='add_title'><a style='color:#133DB6' href='javascript:void(0);'>Task&nbsp;</a><d>|</d><a>&nbsp;Event&nbsp;（"+ctime+"）</a><a class='add_loading'><img src='imgs/loading.gif' /></a><a title='关闭' class='add_close'><img src='imgs/close.gif'/></a></li></ul>");
					$(obj).parents("td").find(".event").find("a:eq(0)").click(
							function(event){
								showtask();
					});
					$(obj).parents("td").find(".event").find(".add_close").click(
							function(event){
								popclose();
					});
					$(obj).parents("td").find(".event").click(
							function(event){
								event.stopPropagation();
					});
					showevent();
				},
				success: function(data, textStatus){
					$(obj).parents("td").find(".event").find("ul").append(data);
					var a=$("#big_calendar").height()-
						  ($(obj).parents("td").find(".event").offset().top-$("#big_calendar").offset().top);
					var b=$(obj).parents("td").find(".event").height()-a;   //自动调整弹窗底部到footer的距离
					if(b>0){
						$(".clear").css("margin-top",b+500+"px");
					}
					$(obj).parents("td").find(".event").find("ul").find(".event_li").hover(
            			function () {
    						$(this).find(".event_li_delete").show();
							$(this).find("a").click(
           						function(){
									var event_edit_input="";                             //存储弹窗中任务内容
									event_edit_input_time=$(this).html().substr(0,33);   //存储弹窗中任务列表每个任务的备忘时间
									if(event_edit_input_time.indexOf("备忘")<0){         //如果含有“备忘”时间则截取后面部分的具体任务内容
										event_edit_input_time="";
										event_edit_input=$(this).html();
									}
									else{
										event_edit_input=$(this).html().substr(33,$(this).html().length);
									}
										
									if(findPosX(this)<=550){
									   $(this).parents("li").find(".event_li_detail").addClass("event_li_detail1").removeClass("event_li_detail");								
									   event_detailclose();
									   $(this).parents("li").find("dl:eq(0)").html(event_edit_input);
									   $(this).parents("li").find(".event_li_detail1").show();
									}							
									else{
										event_detailclose();
										$(this).parents("li").find("dl:eq(0)").html(event_edit_input);
										$(this).parents("li").find(".event_li_detail").show();
									}
							});
  						},
  						function () {
    						$(this).find(".event_li_delete").hide();
  						}	
     				);
					hideloading(".event");
				},
				error: function(){
						hideloading(".event");
						$(obj).parents("td").find(".event").find("ul").append("<li  class='task_none'>加载失败！</li>");
				}
		});
}

//编辑Event任务内容
function editEvent(obj,sid){    
    	var dlHeight=obj.offsetHeight;
		var dlWidth=obj.offsetWidth;
		if($(obj).find("textarea").size()==0){
	  	  if(dlHeight<30){
		 	 dlHeight=25;
		  	 $(obj).html("<textarea id='event_edit_input' style='height:"+dlHeight+"px;width:"+(dlWidth-30)+"px' onclick='canclevent(event)'>"+$(obj).html()+"</textarea>");
	  	  }
	  	  else {
			 $(obj).html("<textarea id='event_edit_input' style='height:"+dlHeight+"px;width:"+(dlWidth-30)+"px' onclick='canclevent(event)'>"+$(obj).html()+"</textarea>");
	  	  }
		}
	
		else{
			var event_edit_input=$(obj).find("#event_edit_input").val();
			if(event_edit_input.replace(/\s+/g, "")=="")
				alert("您的任务不能为空！");
			else if(event_edit_input.indexOf("<")!=-1||event_edit_input.indexOf(">")!=-1) {
				alert("您输入的内容带有特殊符号，请重新输入！");
			}
       		else{
				$.ajax({
						type: "post",
						data: "action=edit_one_task&task="+event_edit_input+"&id="+sid,
						url:  "ajax/tasks_function.php",
						beforeSend: function(XMLHttpRequest){
							showloading(".event");
						},
						success: function(data, textStatus){						
							$(obj).html(event_edit_input);
							$(obj).parents("li").find("a").html(event_edit_input_time+event_edit_input);
							var a=$("#big_calendar").height()-
								 ($(obj).parents("span").offset().top-$("#big_calendar").offset().top);
							var b=$(obj).parents("span").height()-a;   //自动调整弹窗底部到footer的距离
							if(b>0){
								$(".clear").css("margin-top",b+500+"px");
							}
							else{
								set_clear_margin_top();
							}
							$("#"+seletedtd_cache+">div:eq(2)").addClass("div_dis").removeClass("dis_none");
				 			$("#"+seletedtd_cache+">div:eq(2)").html("<a href='mycalendar.php' onclick='canclevent(event)'>日程已经更改！</a>");
							hideloading(".event");
						},
						error: function(){
							alert("修改任务失败！");
						}
			     });
			}
		}
}	

//删除一条event
function deleteEvent(obj,sid){

	   $.ajax({
				type: "post",
				data: "action=delete_one_task&id="+sid,
				url:  "ajax/tasks_function.php",
				beforeSend: function(XMLHttpRequest){
					  showloading(".event");
				},
				success: function(data, textStatus){						
					  $(obj).parents("li").hide();
					  hideloading(".event");
					  $("#"+seletedtd_cache+">div:eq(2)").addClass("div_dis").removeClass("dis_none");
				 	  $("#"+seletedtd_cache+">div:eq(2)").html("<a href='mycalendar.php' onclick='canclevent(event)'>点击更新信息！</a>");
				},
				error: function(){
					  alert("删除任务失败！");
				}
		});
}

//event任务详情窗口关闭
function event_detailclose(){
		for(var i=0;i<$("#"+seletedtd_cache+">.event>ul>.event_li").size();i++){
			if($("#"+seletedtd_cache+">.event>ul>.event_li:eq("+i+")").find(".event_li_detail").size()>0)
				$("#"+seletedtd_cache+">.event>ul>.event_li:eq("+i+")").find(".event_li_detail").hide();	
			else
				$("#"+seletedtd_cache+">.event>ul>.event_li:eq("+i+")").find(".event_li_detail1").hide();	
		}
}

	
	    
/*loading图案的显示和隐藏*/		
function showloading(a){
			 
		$("#"+seletedtd_cache+">"+a+">ul>li>.add_loading").append("<img src='imgs/loading.gif' />");
}
		
function hideloading(a){
		
		$("#"+seletedtd_cache+">"+a+">ul>li>.add_loading").html("");
}		
		
function show_loading(){
    	
		$("#loading").show();
}

function hide_loading(){
   		
		$("#loading").hide();
}	
		

/*关闭弹出窗口*/
function popclose(){
		
		$("#"+seletedtd_cache+">.maketask").hide();
		$("#"+seletedtd_cache+">.event").hide();
		set_clear_margin_top();
}
		
function tipclose(){
		
		$("#"+seleted_tip+">ul").hide();
		$("#"+seleted_tip+">span").hide();
		set_clear_margin_top();
}	
		 
/*邮箱*/

//添加邮箱
function add_email(){
   			 
		var email=$("#email_input").val().replace(/\s+/g, "");
		if(email=="")			 	
			alert("邮箱不能为空！");
		else if(!checkEmail(email))
		    alert("邮箱格式错误！");
		else{
			$.ajax({
					type: "post",
					data: "action=add_emails&email="+email,
					url:  "ajax/emails_function.php",
					beforeSend: function(XMLHttpRequest){
						$("#mail_tip>ul>li:first").html("");
					    $("#mail_tip>ul>li:first").html("<img src='imgs/loading.gif' />");
					},
					success: function(data, textStatus){
						$("#mail_tip>ul").html("");
				    	$("#mail_tip>ul").html("<li><input type='text' name='email_input' id='email_input'/><input type='image' src='imgs/add.png' class='add_delete' onclick='add_email()' title='添加'/></li>"+data);					
					},
					error: function(){	
						$("#mail_tip>ul>li:first").html("");
				    	$("#mail_tip>ul>li:first").html("<input type='text' name='email_input' id='email_input'/><input type='image' src='imgs/add.png' class='add_delete' onclick='add_email()' title='添加'/>");		
						alert("添加失败！");
					}
		  	  });	
		}			  
}

//检查邮箱格式
function checkEmail(email){
	
		var emailRegExp = new RegExp( "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
			
		if (!emailRegExp.test(email)||email.indexOf('.')==-1){	
			return false;
		}			
		else{	
			return true;
		}
}
	
//删除邮箱	
function delete_email(e_id,id){
		
		$.ajax({
				type: "post",
				data: "action=delete_emails&email_id="+e_id,
				url:  "ajax/emails_function.php",
				beforeSend: function(XMLHttpRequest){
					$("#mail_tip>ul>li:first").html("");
				    $("#mail_tip>ul>li:first").html("<img src='imgs/loading.gif' />");
				},
				success: function(data, textStatus){
					$("#mail_tip>ul>li:eq("+id+")").hide();
					$("#mail_tip>ul>li:first").html("");
				    $("#mail_tip>ul>li:first").html("<input type='text' name='email_input' id='email_input'/><input type='image' src='imgs/add.png' class='add_delete' onclick='add_email()'/>");					
				},
				error: function(){
				    $("#mail_tip>ul>li:first").html("");
				    $("#mail_tip>ul>li:first").html("<input type='text' name='email_input' id='email_input'/><input type='image' src='imgs/add.png' class='add_delete' onclick='add_email()'/>");		
					alert("删除失败！");
				}
		  });
}

//获得帮助信息
function gethelp(){  

       $.ajax({
				type: "post",
				data: "action=get_help",
				url:  "ajax/other_function.php",
				beforeSend: function(XMLHttpRequest){
						show_loading();
				},
				success: function(data, textStatus){						
						$("#calendar").html("");
						$("#calendar").html(data);
						hide_loading();
				},
				error: function(){
						alert("获取帮助信息失败！");
				}
		});
}

/*其他*/

//调整clear的上边距，将clear还原到原位置
function set_clear_margin_top(){
		$(".clear").css("margin-top","0px");
}

//返回td的左边距，动态修改编辑弹窗的位置
function findPosX(obj){   
		var curleft = 0;
		if (obj.offsetParent){ 
  	  		 while (obj.offsetParent){
				curleft += obj.offsetLeft;
				obj = obj.offsetParent; 
	   		}
		} 
		else if (obj.x) curleft += obj.x;
   		return curleft;
}

//返回td的上边距，动态修改clear的位置
function findPosY(obj){    
	var curtop = 0;
    if (obj.offsetParent){
	   while (obj.offsetParent){
			curtop += obj.offsetTop;
			obj = obj.offsetParent;
	   }
    } 
	else if (obj.y) curtop += obj.y;
    return curtop;
}

//取消内外层div的嵌套事件影响
function canclevent(event){        
    
    	if (event.stopPropagation)	
       		 event.stopPropagation();   //基于firefox内核    
		else 	
      		 window.event.cancelBubble=true;  //基于ie的写法
}

//添加到收藏夹
function AddFavorite(sURL, sTitle){ 
		try{
			if (document.all) {
				window.external.addFavorite(sURL, sTitle);     //适用于ie核心
			} 
			else if (window.sidebar) {
				window.sidebar.addPanel(sTitle, sURL, "");   //适用于火狐
				alert("加入成功！");
			}
			else{
				alert("加入收藏失败，请使用Ctrl+D进行添加");
			}
		}
		catch(e) {
			alert("加入收藏失败，请使用Ctrl+D进行添加");
		}
}	 

//删除左右两端的空格
function trim(str){    
     return str.replace(/(^\s*)|(\s*$)/g, "");
}
    