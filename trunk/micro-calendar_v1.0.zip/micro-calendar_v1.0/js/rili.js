var   CalendarDate=new   Array(20); 
var   madd=new   Array(12); 
var   day=new   Date(); 
var   tgString= "甲乙丙丁戊己庚辛壬癸 "; 
var   dzString= "子丑寅卯辰巳午未申酉戌亥 "; 
var   numString= "一二三四五六七八九十 "; 
var   monString= "正二三四五六七八九十冬腊 "; 
var   weekString= "日一二三四五六 "; 
var   sx= "鼠牛虎兔龙蛇马羊猴鸡狗猪 "; 
var   cYear; 
var   cMonth; 
var   cHour; 
var   cDateString; 
var   DateString; 

function   initDate() 
{ 
CalendarDate[0]=0x41A95; 
CalendarDate[1]=0xD4A; 
CalendarDate[2]=0xDA5; 
CalendarDate[3]=0x20B55; 
CalendarDate[4]=0x56A; 
CalendarDate[5]=0x7155B; 
CalendarDate[6]=0x25D;     
CalendarDate[7]=0x92D;       
CalendarDate[8]=0x5192B;   
CalendarDate[9]=0xA95;   
CalendarDate[10]=0xB4A;             
CalendarDate[11]=0x416AA;     
CalendarDate[12]=0xAD5;     
CalendarDate[13]=0x90AB5; 
CalendarDate[14]=0x4BA; 
CalendarDate[15]=0xA5B; 
CalendarDate[16]=0x60A57; 
CalendarDate[17]=0x52B; 
CalendarDate[18]=0xA93; 
CalendarDate[19]=0x40E95; 

madd[0]=0 
madd[1]=31 
madd[2]=59 
madd[3]=90 
madd[4]=120 
madd[5]=151 
madd[6]=181 
madd[7]=212 
madd[8]=243 
madd[9]=273 
madd[10]=304 
madd[11]=334 
} 

function   GetBit(m,n) 
{ 
return(m >> n)&1; 
} 

function   e2c() 
{ 
var   total,m,n,k; 
var   isEnd=false; 
var   tmp=day.getYear(); 
if   (tmp <1900) 
tmp+=1900; 
total=(tmp-2001)*365+Math.floor((tmp-2001)/4)+madd[day.getMonth()]+day.getDate()-23; 
if   (day.getYear()%4==0   &&   day.getMonth()> 1) 
total++; 
for   (m=0;m >= 0;m++) 
{ 
k=(CalendarDate[m] <0xfff)?11:12; 
for   (n=k;n >= 0;n--) 
{ 
if   (total <=29+GetBit(CalendarDate[m],n)) 
{ 
isEnd=true; 
break; 
} 
total=total-29-GetBit(CalendarDate[m],n); 
} 
if   (isEnd) 
break; 
} 
cYear=2001+m; 
cMonth=k-n+1; 
cDay=total; 
if   (k==12) 
{ 
if   (cMonth==Math.floor(CalendarDate[m]/0x10000+1)) 
cMonth=1-cMonth; 
if   (cMonth> Math.floor(CalendarDate[m]/0x10000+1)) 
cMonth--; 
} 
cHour=Math.floor((day.getHours()+3)/2); 
} 

function  GetcDateString() 
{ 
var   tmp= ""; 
tmp+=tgString.charAt((cYear-4)%10);//年干 
tmp+=dzString.charAt((cYear-4)%12);//年支 
tmp+= "("; 
tmp+=sx.charAt((cYear-4)%12); 
tmp+= ")年 "; 
if   (cMonth <1) 
{ 
tmp+= "闰 "; 
tmp+=monString.charAt(-cMonth-1); 
} 
else 
tmp+=monString.charAt(cMonth-1); 
tmp+= "月"; 
tmp+=(cDay <11)? "初":((cDay <20)? "十":((cDay <30)? "甘": "卅")); 
if(cDay%10!=0||cDay==10) 
tmp+=numString.charAt((cDay-1)%10); 
if   (cHour==13) 
tmp+= "夜 "; 
tmp+= "" 
//tmp+=dzString.charAt((cHour-1)%12); 
//tmp+= "时 "; 
cDateString=tmp; 
} 

function   GetDateString() 
{ 
var   today=new   Date();//时间循环时一定要是内部变量 
var   t1=today.getYear(); 
var   time 
time=t1+ "- " 
time+=(today.getMonth()+1)+ "- " 
time+=today.getDate()+ "   " 
time+= "星期"+weekString.charAt(today.getDay())+ "   " 
time+=today.getHours()+ ":" 
time+=(today.getMinutes() <10)? "0": " " 
time+=today.getMinutes()+ ":" 
time+=(today.getSeconds() <10)? "0": " " 
time+=today.getSeconds()+ "   " 
time+=(today.getHours() <=12&&today.getHours()> 0)? "AM ": "PM " 
DateString=time; 
//document.time.showtime.value=time;
document.getElementById("showtime").value= time;
setTimeout( 'GetDateString()',   1000); 
} 
 var sFtv  =   new  Array(
 " 0101 *元旦节 " ,
 " 0202 世界湿地日 " ,
 " 0210 国际气象节 " ,
 " 0214 情人节 " ,
 " 0301 国际海豹日 " ,
 " 0303 全国爱耳日 " ,
 " 0305 学雷锋纪念日 " ,
 " 0308 妇女节 " ,
 " 0312 植树节 孙中山逝世纪念日 " ,
 " 0314 国际警察日 " ,
 " 0315 消费者权益日 " ,
 " 0317 中国国医节 国际航海日 " ,
 " 0321 世界森林日 消除种族歧视国际日 世界儿歌日 " ,
 " 0322 世界水日 " ,
 " 0323 世界气象日 " ,
 " 0324 世界防治结核病日 " ,
 " 0325 全国中小学生安全教育日 " ,
 " 0330 巴勒斯坦国土日 " ,
 " 0401 愚人节 全国爱国卫生运动月(四月) 税收宣传月(四月) " ,
 " 0407 世界卫生日 " ,
 " 0422 世界地球日 " ,
 " 0423 世界图书和版权日 " ,
 " 0424 亚非新闻工作者日 " ,
 " 0501*劳动节 " ,
 " 0502*劳动节假日 " ,
 " 0503*劳动节假日 " ,
 " 0504 青年节 " ,
 " 0505 碘缺乏病防治日 " ,
 " 0508 世界红十字日 " ,
 " 0512 国际护士节 " ,
 " 0515 国际家庭日 " ,
 " 0517 国际电信日 " ,
 " 0518 国际博物馆日 " ,
 " 0520 全国学生营养日 " ,
 " 0523 国际牛奶日 " ,
 " 0531 世界无烟日 " , 
 " 0601 国际儿童节 " ,
 " 0605 世界环境保护日 " ,
 " 0606 全国爱眼日 " ,
 " 0617 防治荒漠化和干旱日 " ,
 " 0623 国际奥林匹克日 " ,
 " 0625 全国土地日 " ,
 " 0626 国际禁毒日 " ,
 " 0701 香港回归纪念日 中共诞辰 世界建筑日 " ,
 " 0702 国际体育记者日 " ,
 " 0707 抗日战争纪念日 " ,
 " 0711 世界人口日 " ,
 " 0730 非洲妇女日 " ,
 " 0801 建军节 " ,
 " 0808 中国男子节(爸爸节) " ,
 " 0815 抗日战争胜利纪念 " ,
 " 0908 国际扫盲日 国际新闻工作者日 " ,
 " 0909 毛泽东逝世纪念 " ,
 " 0910 中国教师节 " , 
 " 0914 世界清洁地球日 " ,
 " 0916 国际臭氧层保护日 " ,
 " 0918 九·一八事变纪念日 " ,
 " 0920 国际爱牙日 " ,
 " 0927 世界旅游日 " ,
 " 0928 孔子诞辰 " ,
 " 1001*国庆节 世界音乐日 国际老人节 " ,
 " 1002*国庆节假日 国际和平与民主自由斗争日 " ,
 " 1003*国庆节假日 " ,
 " 1004 世界动物日 " ,
 " 1006 老人节 " ,
 " 1008 全国高血压日 世界视觉日 " ,
 " 1009 世界邮政日 万国邮联日 " ,
 " 1010 辛亥革命纪念日 世界精神卫生日 " ,
 " 1013 世界保健日 国际教师节 " ,
 " 1014 世界标准日 " ,
 " 1015 国际盲人节(白手杖节) " ,
 " 1016 世界粮食日 " ,
 " 1017 世界消除贫困日 " ,
 " 1022 世界传统医药日 " ,
 " 1024 联合国日 " ,
 " 1031 世界勤俭日 " ,
 " 1107 十月社会主义革命纪念日 " ,
 " 1108 中国记者日 " ,
 " 1109 全国消防安全宣传教育日 " ,
 " 1110 世界青年节 " ,
 " 1111 国际科学与和平周(本日所属的一周) " ,
 " 1112 孙中山诞辰纪念日 " ,
 " 1114 世界糖尿病日 " ,
 " 1117 国际大学生节 世界学生节 " ,
 " 1120 *彝族年 " ,
 " 1121 *彝族年 世界问候日 世界电视日 " ,
 " 1122 *彝族年 " ,
 " 1129 国际声援巴勒斯坦人民国际日 " ,
 " 1201 世界艾滋病日 " ,
 " 1203 世界残疾人日 " ,
 " 1205 国际经济和社会发展志愿人员日 " ,
 " 1208 国际儿童电视日 " ,
 " 1209 世界足球日 " ,
 " 1210 世界人权日 " ,
 " 1212 西安事变纪念日 " ,
 " 1213 南京大屠杀(1937年)纪念日！紧记血泪史！ " ,
 " 1220 澳门回归纪念 " ,
 " 1221 国际篮球日 " ,
 " 1224 平安夜 " ,
 " 1225 圣诞节 " ,
 " 1226 毛泽东诞辰纪念 " )
 
 function getfestival(m,d){
	 if(m<10) m="0"+m;
	 if(d<10) d="0"+d;
	 var str=m+""+d;
	 for(var i=0;i<sFtv.length;i++){
		 if(sFtv[i].indexOf(str)!=-1){
		   return sFtv[i].substr(5,sFtv[i].length-1);}
	 }
	 return "(无节日信息)";
 }
 
 function getWeek(y,m,d){    //获取星期数
	var sDate=new Date();            
	sDate.setFullYear(y,m-1,d);
	var week=new Array("日","一","二","三","四","五","六");
	return week[sDate.getDay()];
 }
 
 function getDate_info(){
	initDate(); 
	e2c(); 
	GetcDateString(); 
	$.ajax({
				type: "post",
				dataType: "json",
				url: "ajax/time_function.php",
				success: function(data, textStatus){
					var myYear = data.year;
					var myMon = data.mon;
					var myDay = data.day;
				    $("#today_info").html("今日：星期"+getWeek(myYear,myMon,myDay)+" "+myYear+"年"+myMon+"月"+myDay+"日("+cDateString+")");
					$("#today_festival").html("节日信息："+getfestival(myMon,myDay));
				},
				error: function(){
					$("#today_info").html("获取日期信息失败！");
					$("#today_festival").html("获取节日信息失败！");
				}
	});
}
	
	 