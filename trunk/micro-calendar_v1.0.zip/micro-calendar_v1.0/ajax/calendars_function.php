<?php

/**
 * 获取大日历视图和小日历视图文件
*/

		header("Content-Type:text/html;charset=utf-8");
			
        session_start();
 
        include_once( 'calendar.class.php' );         
		 
		$s=new calendar($_SESSION['username']);
		
		$pre_mon = $next_mon = $_POST['mon'];
		$pre_year = $next_year = $_POST['year'];
		
		if($_POST['mon'] == 1) {
		
			$pre_mon = 12;
			$pre_year --;
			$next_mon ++;
		}
		
		else if($_POST['mon'] == 12){
		
		    $pre_mon --;
			$next_mon = 1;	
			$next_year ++;
		}
		
		else{
		
		    $pre_mon --;
			$next_mon ++;	
		}
		
		if($_POST['action']=="get_smallcalendar"){
		
			echo" <li>
		        <a class='smallcalendar_left' href='javascript:void(0);' 
				   onclick='smallcalendar_change(".$pre_year.",".$pre_mon.")' title='上一月份'></a>
				<a class='smallcalendar_center' id='YMD'>".$_POST['year']."年".$_POST['mon']."月"."</a>
				<a class='smallcalendar_right' href='javascript:void(0);' 
				   onclick='smallcalendar_change(".$next_year.",".$next_mon.")' title='下一月份'></a>
			  </li>";
         		 
			$s->get_calendar($_POST['year'],$_POST['mon'],1,"small_calendar");
			
		}
		
		else if($_POST['action']=="get_bigcalendar"){
		
		    echo" <div id='big_calendar_title'>".$_POST['year']."年".$_POST['mon']."月"."</div>
				  <a class='bigcalendar_left' href='javascript:void(0);' 
				     onclick='bigcalendar_change(".$pre_year.",".$pre_mon.")' title='上一月份'></a>";
 
		    $s->get_calendar($_POST['year'],$_POST['mon'],1,"big_calendar");
			 
			echo"<a class='bigcalendar_right' href='javascript:void(0);' 
				    onclick='bigcalendar_change(".$next_year.",".$next_mon.")' title='下一月份'></a>";
		
		}
?>
