<?php

/**
 * ��ȡ������ʱ��
*/	

		header("Content-Type:text/html;charset=utf-8");
	
        session_start();
 
        include_once( 'calendar.class.php' );         
		
		$s=new calendar($_SESSION['username']);
		
		$array = array ('year'=>$s->getyear(),'mon'=>$s->getmon(),'day'=>$s->getday());
		
		echo json_encode($array);
		
		
?>
