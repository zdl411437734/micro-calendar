<?php

/**
 * 日程任务的操作
*/		

		header("Content-Type:text/html;charset=utf-8");
	
        session_start();

        include_once( 'calendar.class.php' );		
		
		$s=new calendar($_SESSION['username']);
			
		//获取今日任务列表		
		if($_POST['action'] == "get_today_tasks"){
			  
			$s->get_today_tasks();
		}
		
		//获取任务列表模式
		else if($_POST['action'] == "get_task_list"){
			  
			$s->get_task_list($_POST['first']);
		}
		
		//获取任务弹窗模式
		else if($_POST['action'] == "get_task_pop"){
			  
			$s->get_task_pop($_POST['ctime']);
		}
		
		//新建一个任务
		else if($_POST['action'] == "add_one_task"){
		
			if($_POST['share_wb']=="true"){   //分享到新浪微博
			
				include_once( '../config.php' );  
				include_once( 'saetv2.ex.class.php' );
				
				$c = new SaeTClientV2( WB_AKEY , WB_SKEY , $_SESSION['token']['access_token'] );

			    if($_POST['bw']=="true")
					$text = "#我的微日历# ".$_POST['ctime']." ".$_POST['ntime']."我的日程安排是：".$_POST['task']."。";
				else
					$text = "#我的微日历# ".$_POST['ctime']."我的日程安排是：".$_POST['task']."。";
						
				$c->update($text);	  
			}

			  
			$s->add_one_task($_SESSION['username'],$_POST['task'],$_POST['ctime']." ".$_POST['ntime'],
					
									 $s->getnow(),$_POST['bw'],"false");
		}
		
		//编辑一个任务（弹窗下）
		else if($_POST['action'] == "edit_one_task"){
			  
			$s->edit_one_task($_POST['task'],$_POST['id']);
		}
        
		//删除一个任务
		else if($_POST['action'] == "delete_one_task"){
			  
			$s->delete_one_task($_POST['id']);
		}

?>
