<?php

/**
 * 微日历中需要调用的全部操作方法文件
*/

class calendar{

      private $u_name;
        
      function  __construct($u_name){
        $this->username=$u_name;
      }
      
      /*function printss(){
         echo $this->username;}*/
       
	  //获取日历	
      function get_calendar($year,$month,$day,$which){
		$sq=new calendarsql();
		$con=$sq->linksql();
		if($con){	
			echo "<table id='".$which."' cellpadding='0' cellspacing='0'><tr><td>日</td><td>一</td><td>二</td><td>三</td><td>四</td><td>五</td><td>六</td></tr><tr>";
		
		if($month==1) {
			$earlymon_day=date("t",mktime(0,0,0,12,$day,$year-1));
			$nextmon_day=date("t",mktime(0,0,0,2,$day,$year));
		}		
		else if($month==12) {
		  $earlymon_day=date("t",mktime(0,0,0,11,$day,$year));
		  $nextmon_day=date("t",mktime(0,0,0,1,$day,$year+1));
		}		
	    else{
	      $earlymon_day=date("t",mktime(0,0,0,$month-1,$day,$year));
		  $nextmon_day=date("t",mktime(0,0,0,$month+1,$day,$year));  
		}		
        $first_day=date("w",mktime(0,0,0,$month,$day,$year));
		
	    $j=1;
        for($f=0;$f<$first_day;$f++){
			echo "<td style='color:#C2C0C0'>".($earlymon_day-$first_day+$j)."</td>";
			$j++;
	    }
				
        for($i=1;$i<=date("t",mktime(0,0,0,$month,$day,$year));$i++){
	   
			if($month<10) 
				$ctime=$year."-0".$month."-";	  //计算日历中的日期便于查询数据库
			else 
				$ctime=$year."-".$month."-";
			if($i<10) 
				$ctime=$ctime."0".$i;	  
			else 
				$ctime=$ctime.$i;	
	  
			$sql="select substr(task,1,5) as task from myschedule where nickname='".$this->username."' and bw='true' and substr(task_date,1,10)='".$ctime."' order by task_date asc";
			$sql1="select substr(task,1,5) as task from myschedule where nickname='".$this->username."' and bw='false' and substr(task_date,1,10)='".$ctime."' order by now_date asc";
			$result = mysql_query($sql);
			$result1 = mysql_query($sql1);
			$frow=0;
			$bw_count=mysql_num_rows($result);
			$rc_count=mysql_num_rows($result1);
			$count=$bw_count+$rc_count;
	   	    
			if($which=="big_calendar") {
				echo "<td><div id='$year";
				if($month<10) echo "0$month"; //改变月数，返回当月的天数
				else echo "$month";
				if($i<10) echo "0$i'";
				else echo "$i'";
				echo " class='position_div'> ";	   
				echo $i;  
		   
				if($count<3){
					while($row = mysql_fetch_array($result)){
						if($frow<3){
							echo "<div class='div_dis' title='备忘'>".$row['task']."</div>";
							$frow++;}
						else break;
					}
		   
					while($row = mysql_fetch_array($result1)){
						if($frow<3){
							echo "<div class='div_dis' title='普通日程'>".$row['task']."</div>";
							$frow++;}
						else break;
					}
		   
					while($frow<3){
						echo "<div class='div_none'></div>";
						$frow++;
					}
				}
		   
				else{
					while($row = mysql_fetch_array($result)){
						if($frow<2){
							echo "<div class='div_dis' title='备忘'>".$row['task']."</div>";
							$frow++;}
						else break;
					}
		   
					while($row = mysql_fetch_array($result1)){
						if($frow<2){
							echo "<div class='div_dis' title='普通日程'>".$row['task']."</div>";
							$frow++;}
						else break;
					}
		   
					while($frow<3){
						echo "<div class='div_dis'>还有".($count-2)."条</div>";
						$frow++;
					}
				}
		  
				echo "<div class='maketask'></div>
					  <div class='event'></div>
					  <div id='task_triganle'></div></div></td>";    
		   }
	   
		   else {	  
				if($count>0){
					echo "<td class='weight'>".$i;
				}
				else{
					echo "<td class='light'>".$i;
				}
				echo "</td>";
		   }      
								
		   if(date("w",mktime(0,0,0,$month,$i,$year))==6)
				echo "</tr><tr>";
       }
	   
	   $last_day=date("w",mktime(0,0,0,$month,$i,$year));
	   if($last_day!=0){
			$j=1;
			for($f=0;$f<=6-$last_day;$f++){
				echo "<td style='color:#C2C0C0'>".$j."</td>";
				$j++;}
	   }	   
	   echo "</tr></table>";
	   $sq->closesql($con);
	   }
	   $con=null;
	   $sq=null;
   }
 
   //记录用户信息
   function adduser(){
      $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {
	    $sql="select * from myuser where nickname='".$this->username."'";
	    $result=mysql_query($sql);
		if(mysql_num_rows($result)==0){
			$sql="insert into myuser values(null,'".$this->username."','".$this->getnow()."')";
			mysql_query("set names utf-8");
			$result = mysql_query($sql);
        }
		$sq->closesql($con);
      }
	  $con=null;
	  $sq=null;
   }
 
   //新建一个任务
   function add_one_task($nickname,$task,$task_date,$now_date,$bw,$sends){
      $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {
        $sql="insert into myschedule values(null,'".$nickname."','".$task."','".$task_date."','".$now_date."','".$bw."','".$sends."')";
		mysql_query("set names utf-8");
		$result = mysql_query($sql);
		if($result) 
			echo "已保存！";
		else 
			echo "未保存！";
		
		$sq->closesql($con);
      }
	  $con=null;
	  $sq=null;	
   }
 
   //删除一个任务
   function delete_one_task($id){
      $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {
	    $sql="DELETE from myschedule where Id='".$id."'";
		mysql_query($sql);
		
		$sq->closesql($con);
	  }
	  $con=null;
	  $sq=null;
   } 
   
   //编辑一个任务
   function edit_one_task($task,$id){
      $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {
	    $sql="UPDATE myschedule SET task='".$task."'where Id='".$id."'";  
	    mysql_query($sql);
		$sq->closesql($con);
	  }
	  $con=null;
	  $sq=null;
   } 
   
   //获取任务列表（弹窗模式）
   function get_task_pop($ctime){
      $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {
		   $sql="select Id,task,task_date from myschedule where nickname='".$this->username."' and bw='true' and substr(task_date,1,10)='".$ctime."' order by task_date asc";
		   $sql1="select Id,task from myschedule where nickname='".$this->username."' and bw='false' and substr(task_date,1,10)='".$ctime."' order by now_date asc";
		   $result = mysql_query($sql);
		   $result1 = mysql_query($sql1);
		   $count=mysql_num_rows($result)+mysql_num_rows($result1);
					
		   if($count>0){
			 $i=9;  
			 while($row = mysql_fetch_array($result)){
				 echo "<li class='event_li'><span class='event_flag'><img src='imgs/bw.png' title='备忘' /></span>";
				 echo "<a title='点击编辑此记录'>备忘：".substr($row['task_date'],11,5)."&nbsp;&nbsp;|&nbsp;&nbsp;".$row['task']."</a>";
				 echo "<span class='event_li_delete' onclick='deleteEvent(this,".$row['Id'].")' title='删除'><img src='imgs/delete.gif'/></span>		   
					   <span class='event_li_detail'>
					   <dl title='点此编辑，点击旁边空白保存' onclick='editEvent(this,".$row['Id'].")' class='event_li_detail_text'></dl>
					   <dl class='event_li_detail_close' title='关闭' onclick='event_detailclose()'><img src='imgs/close.gif'/></dl>
					   <dl class='event_li_detail_clear'></dl></span></li>";
				 $i++;
			 }	
			 
			 while($row = mysql_fetch_array($result1)){
				 echo "<li class='event_li'>";
				 echo "<a title='点击编辑此记录'>".$row['task']."</a>";
				 echo "<span class='event_li_delete' onclick='deleteEvent(this,".$row['Id'].")' title='删除'><img src='imgs/delete.gif'/></span>		   
					   <span class='event_li_detail'>
					   <dl title='点此编辑，点击旁边空白保存' onclick='editEvent(this,".$row['Id'].")' class='event_li_detail_text'></dl>
					   <dl class='event_li_detail_close' title='关闭' onclick='event_detailclose()'><img src='imgs/close.gif'/></dl>
					   <dl class='event_li_detail_clear'></dl></span></li>";
				 $i++;
			 }			 
			  echo "<li class='event_clear'>
				   </li>";
		   }
			else if($count==0) {
				  echo "<li class='task_none'><a>今日无日历项。</a></li>";
				  echo "<li class='event_clear'>
					   </li>";
			}
			$sq->closesql($con);
	   }	   
	  $con=null;
	  $sq=null;
   }
   
   //获取任务列表（列表模式）
   function get_task_list($first_page){
      $page=20;
      $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {
		 $first_sql="select Id from myschedule where nickname='".$this->username."' order by task_date desc";//计算条数
		 $first_result = mysql_query($first_sql); 
	     $count=mysql_num_rows($first_result);
	      	   
	     $sql="select * from myschedule where nickname='".$this->username."' order by task_date desc LIMIT ".$first_page.",".$page;		 
	     $result=mysql_query($sql);

		 while($row = mysql_fetch_array($result)){
		    $insert_temp_sql = "insert into temp_table values('".$row['Id']."','".$row['nickname']."','".$row['task']."','".$row['task_date']."','".$row['bw']."')";
			mysql_query("set names utf-8");
			mysql_query($insert_temp_sql);
		}
		
         $sql1="select distinct substr(task_date,1,10) as task_date from temp_table where nickname='".$this->username."' group by task_date order by task_date desc";
		 $result1=mysql_query($sql1);
		 
		 echo "<div class='thingstitle'>我的日程记录：</div>";
	     if($count<=$first_page||$count<=0){ 
			echo "<div class='red_tips'>&nbsp;&nbsp;这里还没有您的记录，快点写点东西吧……</div>";
			echo "<div class='other_pages'><a class='up_page'>上一页</a><a class='up_page'>下一页</a><a class='jump_page'>跳转到<input type='text' onkeyup='getmonList((this.value-1)*20)'/> 页</a></div>";
		 }
		 else{
		    $j=0;
			$i=0;
			echo " <div id='thingslist'>";
			while($row1 = mysql_fetch_array($result1)){
			
					$begin=$row1['task_date'];
					echo "<div class='thingone'>
						  <a class='thingone_data'>".$begin."</a>
						  <a class='thingone_list'>";	   
					$sql2 = "select Id,task,task_date from temp_table where nickname='".$this->username."' and bw='true' and substr(task_date,1,10)='".$begin."' order by task_date asc";	
					$sql3 = "select Id,task from temp_table where nickname='".$this->username."' and bw='false' and substr(task_date,1,10)='".$begin."' order by task_date asc";	
					$result2 = mysql_query($sql2);
					$result3 = mysql_query($sql3);
					
					while($row2 = mysql_fetch_array($result2)){			
						echo "<span>";
						echo "备忘：".substr($row2['task_date'],11,5)."&nbsp;&nbsp;|&nbsp;&nbsp;";
						echo $row2['task']."<tt onclick='deleteoneTask_List(this,".$row2['Id'].")'>（删除）</tt></span>";
						$j++;
					}
					
					while($row3 = mysql_fetch_array($result3)){			
						echo "<span>";
						//echo "普通：";
						echo $row3['task']."<tt onclick='deleteoneTask_List(this,".$row3['Id'].")'>（删除）</tt></span>";
						$j++;
					}
		
					echo "</a></div>";
				}			 
		    echo "<div class='pages'>";
		    if($first_page==0){
				if($count<=$page) echo "<a class='up_page'>上一页</a><a class='up_page'>下一页</a>";
				else echo "	
		             <a class='up_page'>上一页</a>
					 <a class='up_page' href='javascript:void(0)' onclick='getmonList(".($first_page+$page).")'>下一页</a>";
			}
			else if($first_page>0){
				if($count>$first_page+$page) echo "
			         <a class='up_page' href='javascript:void(0)' onclick='getmonList(".($first_page-$page).")'>上一页</a>
					 <a class='up_page' href='javascript:void(0)' onclick='getmonList(".($first_page+$page).")'>下一页</a>";
				else echo "  
			         <a class='up_page' href='javascript:void(0)' onclick='getmonList(".($first_page-$page).")'>上一页</a>
			 		 <a class='up_page'>下一页</a>"; 
			}
		    echo "<a class='jump_page'>跳转到<input type='text' onkeyup='getmonList((this.value-1)*20)'/> 页</a></div></div>"; 
		 	$sql4="delete from temp_table where nickname='".$this->username."'";
	   		mysql_query($sql4);	
			}
			$sq->closesql($con);
		}
	  $con=null;
	  $sq=null;
    }
   
   //获取提醒邮箱列表
   function get_emails(){
	  $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {	
		$i=1;	  
			  
		$sql="select Id,email from myemail where nickname='".$this->username."'";
	    $result = mysql_query($sql);

		echo "<li><input type='text' name='email_input' id='email_input'/>
					  <input type='image' src='imgs/add.png' class='add_delete' onclick='add_email()'/>
			 </li>";

		while($row = mysql_fetch_array($result)){
		    echo "<li title='".$row['email']."'>".$row['email']."<input type='image' src='imgs/delete.png' class='add_delete' onclick='delete_email(".$row['Id'].",".$i.")'/></li>";
			$i++;
		}
		
		$sq->closesql($con);
	  }
	  $con=null;
	  $sq=null;
	}
	
	//添加提醒邮箱
	function add_emails($email){
	  $email_count=5;  //设置最多可添加几个邮箱
	  $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {	
		$sql="select nickname from myemail where nickname='".$this->username."'";
		$result=mysql_query($sql);
		
		if(mysql_num_rows($result)<$email_count){
		
			$sql="select email from myemail where nickname='".$this->username."' and email='".$email."'";
			$result=mysql_query($sql);
			
			if(mysql_num_rows($result) == 0){
			
				$sql="insert into myemail values(null,'".$this->username."','".$email."')";
				mysql_query("set names utf-8");
				mysql_query($sql);
			}
		}	
			
		$i=1;	  
		$sql="select Id,email from myemail where nickname='".$this->username."'";
	    $result = mysql_query($sql);
			 
		while($row = mysql_fetch_array($result)){
			
		    echo "<li title='".$row['email']."'>".$row['email']."<input type='image' src='imgs/delete.png' class='add_delete' onclick='delete_email(".$row['Id'].",".$i.")' title='删除'/></li>";
			$i++;
		}
		
		$sq->closesql($con);
	  }
	  $con=null;
	  $sq=null;
	}
    
    //删除提醒邮箱	
	function delete_emails($email_id){
	  $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {	
		$sql="delete from myemail where Id='".$email_id."' and nickname='".$this->username."'";
	    mysql_query($sql);
		
		$sq->closesql($con);
	  }
	  $con=null;
	  $sq=null;
	}

   //获取今日任务列表	
   function get_today_tasks(){
	  $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {	
		$sql="select task from myschedule where nickname='".$this->username."' and substr(task_date,1,10)='".$this->gettoday()."'";	          
		$result = mysql_query($sql);
			  
		if(mysql_num_rows($result)==0)
				 
			echo "<li>今日（".$this->gettoday()."）无任务。</li>";

		else{
			  
			echo "<li>今日（".$this->gettoday()."）任务为：</li>";
			mysql_query("set names utf-8");
			$i=1;  
			while($row = mysql_fetch_array($result)){
				
				echo "<li>".$i."、".$row['task']."</li>";
				$i++;
			}
		}
		
		$sq->closesql($con);
	  }
	  $con=null;
	  $sq=null;
	}		
   
   //搜索
   function search_tasks($keyword){
      $sq=new calendarsql();
	  $con=$sq->linksql();
	  if($con)
	  {
		  $j=0;
		  $sql="select Id,task,task_date,bw from myschedule where nickname='".$this->username."' and task like '%".$keyword."%' order by task_date desc"; //搜索
		  //$sql="select * from myschedule where nickname='".$this->username."' and task like '%".$keyword."%' or task_date like '%".$keyword."%' order by task_date desc";
		  $result = mysql_query($sql); 
		  $count=mysql_num_rows($result);
		  echo "<div class='thingstitle'>搜索&nbsp<font style='color:red'>".$keyword."</font>&nbsp结果：</div><div id='thingslist'>";	   
		   
		  if($count<=0){
			 echo "<div class='red_tips'>&nbsp;&nbsp;这里还没有您的记录。</div></div>";
		  }
		  else{
		     while($row = mysql_fetch_array($result)){
				echo "<div class='thingone'>
						<a class='thingone_data'>".mb_substr($row['task_date'],0,10,'utf-8')."</a>
						<a class='thingone_list'>";
				echo "<span>";
				if($row['bw']=="true") 
					echo "备忘任务：".substr($row['task_date'],11,5)."&nbsp;&nbsp;|&nbsp;&nbsp;";
				else
					echo "普通日程：";
				echo $row['task']."<tt onclick='deleteoneTask_List(this,".$row['Id'].")'>（删除）</tt></span></a></div>";
				$j++;
			 }
		  }
		  $sq->closesql($con);
      }
	  $con=null;
	  $sq=null;
    }
   
   //获取帮助信息
   function get_help(){
		echo "
		<div class='help'>
		<h>新手帮助&nbsp;>></h>
		<p>应用简介：<br/>	&nbsp;&nbsp;&nbsp;&nbsp;欢迎您使用新浪微日历应用。微日历是一款方便随时随地记录、管理您每日的行程安排、工作日程、备忘任务等的新浪微博应用工具。当您添加提醒邮箱后系统将自动发送邮件提醒您每日的日程事项。<br/>
		<br/>
		使用帮助：<br/>
		1、<font style='color:#F56898'>点击左上方图标<img src='imgs/email.png' title='添加提醒邮箱' width='20' height='20'/>可以添加多个（最多可达5个）提醒邮箱地址，系统将在您指定的时间内自动发送日程提醒邮件。您可以随时增加和删除邮箱地址。</font><br/>
		2、点击左上方图标<img src='imgs/task.png' title='今日任务' width='20' height='20'/>可以快速获取当天的任务列表。<br/>
		3、点击左上方图标<img src='imgs/small_calendar.png' title='日历简洁模式' width='20' height='20'/>可以快速翻阅日历，查看某天是否有任务。<br/>
		4、右上角有日历和日程列表的切换按钮，可以进行日历模式或者列表模式自由切换。<br/>
		5、<font style='color:#F56898'>在搜索框中输入格式为“201203”，可立即跳转到2012年3月的日历。</font>输入其他关键字则需要点击搜索按钮进行记录搜索。<br/>
		6、点击日历中的每一天可以添加当天的日程、备忘、任务，Task（添加日程任务框）、Event（显示当天日程安排列表）。<br/>  
		7、在Task中添加日程任务时，<font style='color:#F56898'>点击界面上时间的各位数字可以设置日程的具体时间。</font>勾选备忘，则将会在Event任务显示列表中自动帮您将此项置顶显示并附加备忘时间，方便查看到今天特别重要的备忘日程，而其他日程则会显示为普通日程。同时您还可以将日程分享到新浪微博。<br/> 
		8、点击Event获取当前日期的日程列表，点击每条记录右边对应的删除图标即可删除此条任务。点击每一条记录，将会弹出修改框，点击文字即可修改，点击文字旁边的空白处即可保存。<br/>			
		9、其他功能请自行了解使用。<br/>
		10、若您收不到系统的提醒邮件时请查看您邮箱中的垃圾信箱。<br/>
		&nbsp;&nbsp;&nbsp;感谢您的使用！
		</p></div>
		";
   }
  
   //获取当前时间
   function getnow(){
      date_default_timezone_set('Asia/Shanghai'); 
      return date("Y-m-d H:i:s");}  
   
   //获取当天日期
   function gettoday(){
      date_default_timezone_set('Asia/Shanghai'); 
      return date("Y-m-d");}
	 
   //获取当天年份	 
   function getyear(){
      date_default_timezone_set('Asia/Shanghai'); 
      return date("Y");}
	
	//获取当天月份数
	function getmon(){
      date_default_timezone_set('Asia/Shanghai'); 
	  if(substr(date("m"),0,1)=="0")
	  return substr(date("m"),1,1);
	  else return substr(date("m"),0,2);}
	  
	 //获取当天日数 
	 function getday(){
      date_default_timezone_set('Asia/Shanghai'); 
      if(substr(date("d"),0,1)=="0")
	  return substr(date("d"),1,1);
	  else return substr(date("d"),0,2);}
}

//MySql数据库连接类，若是别的平台需修改数据库连接
class calendarsql{

    //连接数据库
    function linksql(){
    /*
	  $host = 'SAE_MYSQL_HOST_M';
      $user_name = 'SAE_MYSQL_USER';
      $password = 'SAE_MYSQL_PASS';
      $conn = mysql_connect($host,$user_name,$password);
	  mysql_query("SET NAMES 'utf8'",$conn);
      $db_selected = mysql_select_db("SAE_MYSQL_DB", $conn);
      return $conn;
	*/
      $link=mysql_connect(SAE_MYSQL_HOST_M.':'.SAE_MYSQL_PORT,SAE_MYSQL_USER,SAE_MYSQL_PASS);
      if($link){
		   mysql_select_db(SAE_MYSQL_DB,$link);
           return $link;  
	  }    
    }
	  
	//关闭数据库连接  
	function closesql($con){
	   mysql_close($con);
    }
	  
}
?>