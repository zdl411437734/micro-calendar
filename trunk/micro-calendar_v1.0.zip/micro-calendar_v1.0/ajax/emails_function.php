<?php

/**
 * �����б���ȡ�����ӡ�ɾ��
*/

        session_start();

        include_once( 'calendar.class.php' );         
		 
		$s=new calendar($_SESSION['username']);
			  
		if($_POST['action'] == "get_emails"){
		
			$s->get_emails();
			 	
		}
		
		else if($_POST['action'] == "add_emails"){
		
			$s->add_emails($_POST['email']);
			 	
		}
		
		else if($_POST['action'] == "delete_emails"){
		
			$s->delete_emails($_POST['email_id']);
			
		}
		
		else{}
		
?>
