<?php

/**
 * �����ͻ�ȡ������Ϣ
*/

        session_start();

        include_once( 'calendar.class.php' );         
		 
		$s=new calendar($_SESSION['username']);
			  
		if($_POST['action'] == "search_data"){
		
			$s->search_tasks($_POST['keyword']);
			 	
		}
		
		else if($_POST['action'] == "get_help"){
		
			$s->get_help();
			 	
		}
		
?>
		 
		 
		   