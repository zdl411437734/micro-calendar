<?php
  session_start();
  $_SESSION['username']="";
  header('Location: http://www.weibo.com/');
  ?>