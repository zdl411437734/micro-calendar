<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php

/**
 * 定时发送提醒邮件文件
*/	

    include_once( 'ajax/calendar.class.php' );
    $s=new calendar("");
    $datetime=$s->gettoday();
	$ts=new calendarsql();    
    $mail = new SaeMail();
	
    $from=""; //此处填写发送给用户提醒邮件的邮箱，如果使用的是新浪SAE平台，推荐使用新浪邮箱。
    $psw="";  //此处填写发送邮箱的密码
	$smtp="smtp.sina.com";   //此处可参照新浪SAE的Mail服务：http://apidoc.sinaapp.com/sae/SaeMail.html
	$subject=$datetime."的工作日程提醒（微日历应用）";   //提醒邮件标题
 
    $con=$ts->linksql();
    if($con){
        
      $sql="select nickname from myschedule where substr(task_date,1,10)='".$datetime."' and sends='false' group by nickname";
         
      $result = mysql_query($sql);
         
      while($row = mysql_fetch_array($result)){
         
		 $send_flag=false;   //是否已经发送标志
         $i=1;
         $message="";        //发送邮件正文   
         $sql1="select * from myschedule where nickname='".$row['nickname']."'and substr(task_date,1,10)='".$datetime."' and sends='false' order by now_date asc";
               
         $result1 = mysql_query($sql1);
               
         $message=$message."<div style='width:506px;height:auto;overflow:hidden;background-color:#f7f7f7;border:6px solid #d8e3e8;
						color:#111;zoom:1;padding:15px;margin:0px auto 0px;
						-moz-border-radius:5px;-webkit-border-radius:5px;-khtml-border-radius:5px;border-radius:5px;'>
						<ul style='padding:0;font-size:13px;margin:0;hite-space:normal;word-break:break-all;'>
						<li style='width:470px;height:auto;float:left;list-style:none;margin:0px auto 10px;font-size:14px;font-weight:700;'>
						Hi，".$row['nickname']."</li>
						<li style='width:470px;height:auto;float:left;list-style:none;margin:5px auto 20px;font-weight:400;color:4D4D4D;'>
						<a href='http://wrili.sinaapp.com' target='_blank'  style='color:0087CA;'>微日历</a>&nbsp;温馨提醒：您今天(".$datetime.")的日程安排为：</li>";
        while($row1 = mysql_fetch_array($result1)){
            
			if($row1['bw']=="true")
				$message=$message."<li style='width:470px;height:auto;float:left;list-style:none;
				border-bottom: 1px dashed #CCCCCC;margin:0px auto 15px;'>".$i.".【备忘".substr($row1['task_date'],11,5)."】".$row1["task"]."</li>";
            
			else
				$message=$message."<li style='width:470px;height:auto;float:left;list-style:none;
				border-bottom: 1px dashed #CCCCCC;margin:0px auto 15px;'>".$i.". ".$row1["task"]."</li>";
            $i++;
                   
        }
				
			$message=$message."<li style='width:470px;height:auto;float:left;color:#4D4D4D;line-height:18px;list-style:none;
								margin:5px 0px 0px 0px;'>
								 <p>此为系统邮件，请勿回复。</p>
								</li>
							   </ul></div>";			 
             echo $message;	
			
			$sql3="select email from myemail where nickname='".$row['nickname']."'"; 
                
            $result3 = mysql_query($sql3);
                
            while($row3 = mysql_fetch_array($result3)){                
                         
                if($row3['email']!=""&&$row3['email']!=null) {
					$options = array("from"=>$from,"to"=>$row3['email'],"smtp_host"=>$smtp,"smtp_username"=>$from,"smtp_password"=>$psw,"subject"=>$subject,"content"=>$message,"content_type"=>"HTML");
					if($mail->setOpt($options)){
						$ret=$mail->send();
						$send_flag=true;
				    }
				}
				
			}
				
			if($send_flag==true){
					 
				$sql2="UPDATE myschedule SET sends='true' where nickname='".$row['nickname']."'and substr(task_date,1,10)='".$datetime."' and sends='false'"; 
                mysql_query($sql2);
			
			}
           
        } 
			$ts->closesql($con);

    }
		$con = null;
		$ts = null;
		$s = null;
		
?>