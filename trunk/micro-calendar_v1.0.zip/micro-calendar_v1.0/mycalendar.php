<?php
session_start();
include_once( 'config.php' );
include_once( 'saetv2.ex.class.php' );

if($_SESSION['token']==false)
header("Location: index.php");
else{
$c = new SaeTClientV2( WB_AKEY , WB_SKEY , $_SESSION['token']['access_token'] );
$uid_get = $c->get_uid();
$uid = $uid_get['uid'];
$user_message = $c->show_user_by_id($uid);//根据ID获取用户等基本信息
$_SESSION['username']=$user_message['screen_name'];
include_once( 'ajax/calendar.class.php' );
$s=new calendar($_SESSION['username']);
$s->adduser();
$this_day=$s->getDay();
//$s->printss();
//echo $_SESSION['username'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<link rel="icon" href="imgs/logo_calendar.ico" type="image/x-icon">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>微日历 | 订阅 管理日程安排、备忘任务的好帮手</title>
<link href="style/index.css" rel="stylesheet" type="text/css" />
</head>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/rili.js"></script>
<script type="text/javascript" src="js/calendar.js"></script>
<body>
<div id="header">
    <div class="nav">
	    <div class="logo">
             <a href="mycalendar.php"><img src="imgs/logo.png" border="0" title="返回首页"/></a>
			 <a id="today"><?=$this_day?></a>
		</div>
		<div class="care">
			 <iframe width="63" height="24" frameborder="0" allowtransparency="true" marginwidth="0" marginheight="0" scrolling="no" border="0" src="http://widget.weibo.com/relationship/followbutton.php?language=zh_cn&width=63&height=24&uid=1870035745&style=1&btn=red&dpc=1"></iframe>
		</div>
		<div class="author"><a href="http://weibo.com/redawn" target="_blank" title="红色黎明Jia">红色黎明Jia</a></div>
	    <div id="search">
		     <input type="text" value="搜索日期/日程/备忘" title="输入如201208月份数或关键字搜索" />
		     <a href="javascript:void(0);" title="搜索"><img src="imgs/search.gif"/></a>		
	    </div>
		<div id="menu">
		   <ul class="menu_ul">
		      <li class="home" title="首页">首页</li>
		      <li class="home" title="加入收藏夹"><img src="imgs/sc.gif"/></li>
	          <li class="user"><img src=<?=$user_message['profile_image_url']?>/><?=$user_message['screen_name']?>
				<ul class="user_ul">
					<li>添加提醒邮箱</li>
					<li>新手帮助</li>
					<li>退出微日历</li>
				</ul>
			  </li>
		   </ul>
		    
		   <div id="loading">正在加载……</div>
		</div>
	</div>  
</div>

<div id="msg_tip" >
		    <div id="mail_tip"><img src="imgs/email.png" title="添加提醒邮箱" width="40" height="40"/><span></span>
				<ul>
				</ul>
 			 </div>
			 <div id="todaytask_tip"><img src="imgs/task.png" title="今日任务" width="40" height="40" /><span></span>
				<ul>
				</ul>
			</div>
			<div id="smallcalendar_tip"><font title="日历简洁模式"><?=$this_day?></font><span></span>
				<ul>		
				</ul>
			</div>
			<div class="day_content">
          		<div id="today_info"></div>
			    <div id="today_festival"></div>
			</div>
			<div id="calendar_list">
			  <a href="javascript:void(0);" title="切换到日历"></a>
			  <a href="javascript:void(0);" title="切换到日程列表"></a>
			</div>
</div>
<!-- JiaThis Button BEGIN -->
<!--<script type="text/javascript" src="js/jiathis_config.js"></script>-->
<script type="text/javascript" src="http://v3.jiathis.com/code/jiathis_r.js?uid=1342602112968778&type=left&amp;move=0&amp;btn=l1.gif" charset="utf-8"></script>
<!-- JiaThis Button END -->

<div id="calendar">
			<a class="bigcalendar_left" href="javascript:void(0);"></a>
			<a class="bigcalendar_right" href="javascript:void(0);"></a>
</div>
<div class="clear"></div>
<div id="footer">
	    <div class="footer1">
	    <h2>这里可以做什么？</h2>
	    <p>您在这里可以记录、查看、管理每日的日程安排、备忘、任务等等，当您填写了有效邮箱之后，系统将会自动开启邮件提醒功能，定时发送邮件提醒您每日的日程备忘事项。
		</p>
		</div>
		<div class="footer2">
		<h2>意见反馈</h2>
		<p>如果您对微日历应用有如何疑问、意见或建议，欢迎反馈。
		</p>
		</div>
		<div class="footer3">
		<h2>新手帮助</h2>
		<p>微日历是一个完全基于新浪微博的日程应用，如果您还没有开通新浪微博,<a href="http://www.weibo.com" target="_blank">请点击这里</a>。
           新手需要操作帮助<a href="javascript:void(0)" onclick="gethelp()">请点击这里</a>获取。<br/></p>
		</div>
</div>
</body>
</html>
<?php }?>