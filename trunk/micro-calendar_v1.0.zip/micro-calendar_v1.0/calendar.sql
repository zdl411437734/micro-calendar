﻿# MySQL-Front 5.1  (Build 4.2)

/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE */;
/*!40101 SET SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES */;
/*!40103 SET SQL_NOTES='ON' */;


# Host: localhost    Database: calendar
# ------------------------------------------------------
# Server version 5.1.51-community

#
# Source for table myemail
#

CREATE TABLE `myemail` (
  `Id` int(8) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# Source for table myschedule
#

CREATE TABLE `myschedule` (
  `Id` int(8) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) DEFAULT NULL,
  `task` text,
  `task_date` datetime DEFAULT NULL,
  `now_date` datetime DEFAULT NULL,
  `bw` varchar(5) DEFAULT 'false',
  `sends` varchar(5) DEFAULT 'false',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# Source for table myuser
#

CREATE TABLE `myuser` (
  `Id` int(8) NOT NULL AUTO_INCREMENT,
  `nickname` varchar(30) DEFAULT NULL,
  `regtime` datetime DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# Source for table temp_table
#

CREATE TABLE `temp_table` (
  `Id` int(8) NOT NULL,
  `nickname` varchar(30) DEFAULT NULL,
  `task` text,
  `task_date` datetime DEFAULT NULL,
  `bw` varchar(5) DEFAULT 'false',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
