<?php
session_start();
include_once( 'config.php' );
include_once( 'saetv2.ex.class.php' );
$o = new SaeTOAuthV2( WB_AKEY , WB_SKEY );
$code_url = $o->getAuthorizeURL( WB_CALLBACK_URL );
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<link rel="icon" href="imgs/logo_calendar.ico" type="image/x-icon">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>微日历 | 订阅 管理日程安排、备忘任务的好帮手</title>
<!–[if IE 6]>
<script type="text/javascript" src="js/DD_belatedPNG.js"></script>
<script>
DD_belatedPNG.fix('.logo, img');
DD_belatedPNG.fix('#index_calendar, background');
</script>
<![endif]–>
<link href="style/index.css" rel="stylesheet" type="text/css" />
</head>
<body>
<?php 
include_once( 'ajax/calendar.class.php' );
if($_SESSION['username']!="")
	echo "<script> location.href='mycalendar.php '</script>";
else{	
	$s=new calendar("");
?>
<div id="header">
    <div class="nav">
	    <div class="logo">
			<img src="imgs/logo.png"/>
			<a id="today"><?php echo $s->getday();?></a>
		</div>
	</div>  
</div>
<?php
		if(strpos($_SERVER['HTTP_USER_AGENT'],'MSIE 6.0') !== false )    //如果是IE6，则显示升级浏览器提醒
		{
?>
<div style="width:820px;height:59px;margin:3px auto 3px;">
<a target="_blank" href="http://windows.microsoft.com/zh-CN/internet-explorer/downloads/ie?ocid=ie6_countdown_bannercode">
	<img src="http://www.theie6countdown.cn/img/banner/upgrade.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." /></a>
</div>
 <?php	
		}
?>
 <div id="index_calendar">
	    <div id="YEAR_MON"><?php echo $s->getyear()."年".$s->getmon()."月";?></div>
		<div id="DAY"><?php echo $s->getday();?></div>
</div>
<div class="login">
     <div>微日历是基于新浪微博的应用，请用新浪微博帐号登录。</div>
	 <?php
		if(strpos($_SERVER['HTTP_USER_AGENT'],'MSIE 6.0') == false )    //如果不是IE6，则显示登录按钮
		{
	 ?>
		<a href="<?=$code_url?>"><img src="imgs/login.png" title="用新浪微博帐号登录" alt="用新浪微博帐号登录" border="0" /></a>	
	 <?php	
		}
	 ?>	
</div>
</body>
</html>
<?php }?>